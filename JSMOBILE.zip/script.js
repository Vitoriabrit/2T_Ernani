/**
 * FUNÇÕES: Sao blocos de código que podem ser reproveitados
 * Funçoões podem ou no ter nomes
 * Podem ou nao receber parametros
 */
// CRIAR OU DECLARAR UMA FUNÇÕES 
function dizOla(nome) {
  // codigo
  console.log('Ola!' + nome)
}
// INVOCAR / CHAMAR UMA FUNÇÃO  
//dizOla('Vitorinha 244')
//dizOla('Robertinha 244')
//dizOla('Natalinha 244')
//+ - * /
// ADIÇÃO
function somaDoisNumeros(x, y) {
  const soma = x + y
  console.log(soma)
}
somaDoisNumeros(7, 9)
somaDoisNumeros(7, 9)
// SUBTRAÇÃO
function subtraiDoisNumeros(x, y) {
  const subtrai = x - y
  console.log(subtrai)
}
somaDoisNumeros(6, 4)
somaDoisNumeros(3, 8)
// MULTIPLICAÇÃO
function mutiplicaDoisNumeros(x, y) {
  const mutiplica = x * y
  console.log(mutiplica)
}
somaDoisNumeros(5, 3)
somaDoisNumeros(4, 5)
// DIVISÃO
function divideDoisNumeros(x, y) {
  const divide = x / y
  console.log(divide)
}
somaDoisNumeros(9, 4)
somaDoisNumeros(2, 1)

somaDoisNumeros(20, 50)
subtraiDoisNumeros(20, 50)
mutiplicaDoisNumeros(20, 50)
divideDoisNumeros(20, 50)
